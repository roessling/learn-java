package de.tu_darmstadt.informatik.skorvan.student;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.reactfx.util.Tuple2;

import de.tu_darmstadt.informatik.skorvan.compile.Compiler;
import de.tu_darmstadt.informatik.skorvan.compile.Precompiler;
import de.tu_darmstadt.informatik.skorvan.persistence.Crypto;
import de.tu_darmstadt.informatik.skorvan.persistence.Task;
import de.tu_darmstadt.informatik.skorvan.persistence.Zipper;
import de.tu_darmstadt.informatik.skorvan.student.gui.Help;
import de.tu_darmstadt.informatik.skorvan.student.gui.KnowledgeBase;
import de.tu_darmstadt.informatik.skorvan.student.gui.StudentCallback;
import de.tu_darmstadt.informatik.skorvan.student.gui.StudentGui;
import de.tu_darmstadt.informatik.skorvan.util.FileUtils;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class StudentMain extends Application implements StudentCallback {

	private Task currentTask;

	private StudentGui gui;

	private Path taskLocation;

	private static final Path TASKPATH = Paths.get("tasks");

	@Override
	public void start(Stage primaryStage) {
		gui = new StudentGui(this);
		gui.init(primaryStage);

		KnowledgeBase.init(new Stage());

		Help.init(new Stage(), this);

		if (taskLocation == null) {
			loadTasks();
		} else {
			Task task = Task.load(taskLocation, false);
			gui.setAvailableTasks(new Task[] { task });
			gui.showTask(task);
			currentTask = task;
		}

		if (!Config.load() || Config.getJDKPath() == null) {
			Config.reset();
			gui.showConfigError();
		}
		System.out.println(System.getProperty("java.version") + "%%%%%version");
		if (System.getProperty("java.version").startsWith("1.8")) {
			System.out.println("setting java home to " + Config.getJDKPath());
			System.setProperty("java.home", Config.getJDKPath() + File.separator + "jre");
		}
	}

	private void loadTasks() {
		ArrayList<Task> tasks = new ArrayList<>(Arrays.asList(Task.loadAll(TASKPATH, false)));
		for (int i = tasks.size() - 1; i >= 0; i--) {
			for (int j = i - 1; j >= 0; j--) {
				if (tasks.get(i).getId().equals(tasks.get(j).getId())) {
					int result = gui.showDuplicate(tasks.get(i), tasks.get(j));
					if (result == StudentGui.EXIT) {
						Platform.exit();
						return;
					} else if (result == StudentGui.KEEP_FIRST) {
						try {
							Files.delete(tasks.get(j).getLocation());
							Files.delete(tasks.get(j).getTestFilePath());
						} catch (IOException e) {
							e.printStackTrace();
						}
						tasks.remove(j);
						break;
					} else if (result == StudentGui.KEEP_SECOND) {
						try {
							Files.delete(tasks.get(i).getLocation());
							Files.delete(tasks.get(i).getTestFilePath());
						} catch (IOException e) {
							e.printStackTrace();
						}
						tasks.remove(i);
					} else if (result == StudentGui.USE_FIRST) {
						tasks.remove(j);
					} else if (result == StudentGui.USE_SECOND) {
						tasks.remove(i);
						break;
					} else if (result == StudentGui.USE_NONE) {
						tasks.remove(i);
						tasks.remove(j);
						if (i - 1 == j) // removed the tasks i and i-1 ->
										// continue with i-2
							i--;
						break;
					}
				}
			}
		}
		gui.setAvailableTasks(tasks.toArray(new Task[0]));
		FileUtils.cleanUp(TASKPATH);
		currentTask = null;
	}

	public void setTaskLocation(Path taskLocation) {
		this.taskLocation = taskLocation;
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void loadTask(Task task) {
		if (currentTask != null) {
			currentTask.setUserCode(gui.getCodeText());
		}
		currentTask = task;
		gui.showTask(task);
	}

	@Override
	public void save() {
		if (currentTask != null) {
			currentTask.setUserCode(gui.getCodeText());
			Task.save(currentTask);
		}
	}

	@Override
	public void run() {
		System.out.println("running");
		if (currentTask != null) {
			gui.clearConsole();
			String className = currentTask.getClassName();
			Tuple2<Integer, Integer> offset = currentTask.writeToJavaFile(gui.getCodeText());

			int lines = gui.getCodeText().split("\n").length;
			ErrorMessageWriter emw = new ErrorMessageWriter(out -> gui.addToCompiler(out + "\n"),
					out -> gui.addToPrecompiler(out + "\n"), gui, currentTask.getCodePrefix().split("\n").length
							+ 1 /* +1 for package info */,
					lines, gui.getCodeText().split("\n")[lines - 1].length());

			Precompiler.checkForErrors(gui.getCodeText(),
					currentTask.getLocation().resolveSibling(className + ".java").toString(), emw);

			if (Config.getJUnitPath() == null)
				gui.showConfigError();

			System.out.println("still running");

			Compiler.setClasspath(currentTask.getLocation().getParent().getParent().toString()
					+ System.getProperty("path.separator") + Config.getJUnitPath());

			if (Compiler.compile(currentTask.getLocation().resolveSibling(className + ".java").toFile(), emw,
					offset.get2(), offset.get1())) {
				// decipher test file to .java
				Crypto.decrypt(currentTask.getLocation().resolveSibling(currentTask.getTestFile()).toFile(),
						currentTask.getLocation().resolveSibling(currentTask.getTestFile() + ".java").toFile());
				TestRunner.runTests(new TestResultWriter(out -> gui.addToTests(out + "\n")),
						currentTask.getLocation().resolveSibling(currentTask.getTestFile() + ".java"),
						currentTask.getClassName(), offset.get2());
				// remove deciphered test file
			}
			currentTask.clean();
		} else {
			System.out.println("current task is null");
		}
	}

	@Override
	public void importTasks(List<File> zips) {
		zips.forEach(p -> Zipper.unzip(p, TASKPATH));
		loadTasks();
	}

	@Override
	public void reset() {
		gui.clearCodeArea();
		currentTask.setUserCode(null);
	}
}